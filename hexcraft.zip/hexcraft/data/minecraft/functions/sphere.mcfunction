fill ~4 ~1 ~1 ~4 ~-1 ~-1 minecraft:ice keep
fill ~-4 ~1 ~1 ~-4 ~-1 ~-1 minecraft:ice keep
fill ~1 ~1 ~4 ~-1 ~-1 ~4 minecraft:ice keep
fill ~1 ~1 ~-4 ~-1 ~-1 ~-4 minecraft:ice keep
fill ~1 ~4 ~1 ~-1 ~4 ~-1 minecraft:ice keep
fill ~1 ~-4 ~1 ~-1 ~-4 ~-1 minecraft:ice keep

fill ~3 ~1 ~-2 ~3 ~-1 ~-2 minecraft:ice keep
fill ~3 ~1 ~2 ~3 ~-1 ~2 minecraft:ice keep
fill ~3 ~2 ~-1 ~3 ~2 ~1 minecraft:ice keep
fill ~3 ~-2 ~-1 ~3 ~-2 ~1 minecraft:ice keep

fill ~-3 ~1 ~-2 ~-3 ~-1 ~-2 minecraft:ice keep
fill ~-3 ~1 ~2 ~-3 ~-1 ~2 minecraft:ice keep
fill ~-3 ~2 ~-1 ~-3 ~2 ~1 minecraft:ice keep
fill ~-3 ~-2 ~-1 ~-3 ~-2 ~1 minecraft:ice keep

fill ~-2 ~1 ~3 ~-2 ~-1 ~3 minecraft:ice keep
fill ~2 ~1 ~3 ~2 ~-1 ~3 minecraft:ice keep
fill ~-1 ~2 ~3 ~1 ~2 ~3 minecraft:ice keep
fill ~-1 ~-2 ~3 ~1 ~-2 ~3 minecraft:ice keep

fill ~-2 ~1 ~-3 ~-2 ~-1 ~-3 minecraft:ice keep
fill ~2 ~1 ~-3 ~2 ~-1 ~-3 minecraft:ice keep
fill ~-1 ~2 ~-3 ~1 ~2 ~-3 minecraft:ice keep
fill ~-1 ~-2 ~-3 ~1 ~-2 ~-3 minecraft:ice keep

fill ~2 ~3 ~1 ~2 ~3 ~-1 minecraft:ice keep
fill ~-2 ~3 ~1 ~-2 ~3 ~-1 minecraft:ice keep
fill ~1 ~3 ~-2 ~-1 ~3 ~-2 minecraft:ice keep
fill ~1 ~3 ~2 ~-1 ~3 ~2 minecraft:ice keep

fill ~2 ~-3 ~1 ~2 ~-3 ~-1 minecraft:ice keep
fill ~-2 ~-3 ~1 ~-2 ~-3 ~-1 minecraft:ice keep
fill ~1 ~-3 ~-2 ~-1 ~-3 ~-2 minecraft:ice keep
fill ~1 ~-3 ~2 ~-1 ~-3 ~2 minecraft:ice keep

setblock ~2 ~-2 ~2 ice keep
setblock ~2 ~-2 ~-2 ice keep
setblock ~-2 ~-2 ~2 ice keep
setblock ~-2 ~-2 ~-2 ice keep

setblock ~2 ~2 ~2 ice keep
setblock ~2 ~2 ~-2 ice keep
setblock ~-2 ~2 ~2 ice keep
setblock ~-2 ~2 ~-2 ice keep

setblock ~ ~-3 ~3 ice keep
setblock ~ ~-3 ~-3 ice keep
setblock ~3 ~-3 ~ ice keep
setblock ~-3 ~-3 ~ ice keep

setblock ~ ~3 ~3 ice keep
setblock ~ ~3 ~-3 ice keep
setblock ~3 ~3 ~ ice keep
setblock ~-3 ~3 ~ ice keep

setblock ~3 ~ ~3 ice keep
setblock ~3 ~ ~-3 ice keep
setblock ~-3 ~ ~3 ice keep
setblock ~-3 ~ ~-3 ice keep







